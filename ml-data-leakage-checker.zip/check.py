#!/usr/bin/env python3
"""ML 전처리 코드 데이터 누수 검사기 (v4).

사용:
    python check.py < 전처리코드.py
    python check.py -c "전체 코드 문자열"
    python check.py 전처리코드.py
    python check.py 노트북.ipynb

출력: 확정위반 / 의심 / 이상없음 / 판정불가 / 전처리코드로보기어려움 등 분류 + 줄 번호 + 수정 방향만.
원본 코드는 수정하지 않고 지적만 한다.
함수 호출 경계/인자 전달 경로도 추적해서, 함수 안에서 만든 fit 객체를 밖에서 train/test 구분 없이 쓰면 그 흐름도 지적한다.
"""

import sys
import argparse
import re
import json
from typing import List, Tuple, Dict, Set

# -------------------- 패턴 --------------------

PATTERNS = {
    "import_ml": re.compile(r"\b(pandas|numpy|sklearn|xgboost|lightgbm|catboost|torch|tensorflow)\b"),
    "split": [
        re.compile(r"train_test_split\s*\("),
        re.compile(r"TimeSeriesSplit\s*\("),
        re.compile(r"KFold\s*\("),
        re.compile(r"StratifiedKFold\s*\("),
        re.compile(r"GroupKFold\s*\("),
        re.compile(r"cross_val_score\s*\("),
        re.compile(r"cross_val_predict\s*\("),
        re.compile(r"\.iloc\s*\[.*\]\s*="),
        re.compile(r"groupby\s*\([^)]*time|date|period|sort_values\s*\("),
    ],
    "fit": [
        re.compile(r"\.fit\s*\("),
        re.compile(r"\.fit_transform\s*\("),
    ],
    "transform_only": [
        re.compile(r"\.transform\s*\("),
        re.compile(r"\.predict\s*\("),
    ],
    "target_encode": [
        re.compile(r"TargetEncoder|target_encoder|target_encode|mean_encode|woe|weight_of_evidence", re.I),
        re.compile(r"\.map\s*\(\s*df\[['\"]?y['\"]?\]|groupby\s*\([^)]*y|transform\s*\(\s*.*mean\s*\(\s*\)"),
    ],
    "shuffle_split": [
        re.compile(r"train_test_split\s*\([^)]*shuffle\s*=\s*True"),
        re.compile(r"train_test_split\s*\([^)]*random_split|sample\s*\(\s*frac|shuffle"),
    ],
    "time_series_hints": [
        re.compile(r"datetime|date|time|sorted|sort_values|timestamp|TimeSeries|rolling|expanding|shift|lag", re.I),
    ],
    "feature_add": [
        re.compile(r"df\[.*\]\s*=|assign\s*\(|merge\s*\(|join\s*\(|concat\s*\(|apply\s*\(|transform\s*\("),
    ],
    "imputer_scale_encode": [
        re.compile(r"SimpleImputer|StandardScaler|MinMaxScaler|RobustScaler|OrdinalEncoder|LabelEncoder|OneHotEncoder|PowerTransformer|KBinsDiscretizer|QuantileTransformer", re.I),
    ],
    "pipeline": [
        re.compile(r"Pipeline\s*\("),
        re.compile(r"make_pipeline\s*\("),
        re.compile(r"ColumnTransformer\s*\("),
    ],
    "transductive_hints": [
        re.compile(r"transductive|semi_supervised|self_training|label_propagation|label_spreading", re.I),
        re.compile(r"semi-supervised|semi supervised"),
    ],
    "function_def": re.compile(r"^def\s+(\w+)\s*\("),
    "class_def": re.compile(r"^class\s+(\w+)"),
    "python_smell": re.compile(r"\b(def|class|import|from|if|elif|else|for|while|return|print|with|try|except|raise|lambda|yield|assert)\b|^\s*#|^\s*['\"]"),
    "assign"  : re.compile(r"^\s*(?P<target>\w+(?:\.\w+)?)\s*=\s*(?P<value>.+)\s*$"),
    "return_stmt": re.compile(r"return\s+(?P<value>.+)$"),
}


def read_source(path: str = None, code: str = None):
    if code:
        return code
    if path:
        if path.lower().endswith(".ipynb"):
            text, _ = read_notebook(path)
            return text
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    return sys.stdin.read()


def read_notebook(path: str) -> Tuple[str, int]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            nb = json.load(f)
    except Exception as e:
        raise ValueError(f"노트북 읽기 실패: {e}")

    if not isinstance(nb, dict) or "cells" not in nb:
        raise ValueError("노트북 JSON 형식이 아님")

    parts = []
    code_cells = 0
    for cell in nb.get("cells", []):
        if cell.get("cell_type") != "code":
            continue
        code_cells += 1
        source = cell.get("source", [])
        if isinstance(source, list):
            source = "".join(source)
        parts.append(source)
    text = "\n\n# %% 셀 구분\n\n".join(parts)
    return text, code_cells


def is_empty(src: str) -> bool:
    return not src or not src.strip()


def is_python_like(src: str) -> bool:
    if is_empty(src):
        return False
    return bool(PATTERNS["python_smell"].search(src))


def is_ml_preprocessing(lines: List[str]) -> bool:
    has_ml_import = any(PATTERNS["import_ml"].search(l) for l in lines)
    has_preproc = any(
        any(p.search(l) for p in PATTERNS["fit"])
        or any(p.search(l) for p in PATTERNS["split"])
        or any(p.search(l) for p in PATTERNS["imputer_scale_encode"])
        for l in lines
    )
    return has_ml_import and has_preproc


def find_lines(lines: List[str], patterns: List) -> List[Tuple[int, str]]:
    out = []
    for i, l in enumerate(lines, start=1):
        for p in patterns:
            if p.search(l):
                out.append((i, l.strip()))
                break
    return out


def find_lines_all(lines: List[str], patterns: List) -> List[Tuple[int, str]]:
    out = []
    for i, l in enumerate(lines, start=1):
        for p in patterns:
            if p.search(l):
                out.append((i, l.strip()))
    return out


def find_boundaries(lines: List[str]) -> List[Tuple[int, str]]:
    return find_lines(lines, PATTERNS["split"]) + find_lines(lines, [
        re.compile(r"^train\s*=\s*|^test\s*=\s*|^val\s*=\s*|^X_train\s*=\s*|^X_test\s*=\s*|^y_train\s*=\s*|^y_test\s*=\s*"),
        re.compile(r"iloc\[.*:\s*,\s*:\s*\]"),
    ])


def build_function_scopes(lines: List[str]) -> Dict[int, str]:
    scopes: Dict[int, str] = {}
    stack = []
    for i, l in enumerate(lines, start=1):
        stripped = l.strip()
        m = PATTERNS["function_def"].search(stripped)
        if not m:
            m = PATTERNS["class_def"].search(stripped)
        if m:
            name = m.group(1) or "<anon>"
            stack.append(name)
        if stack:
            scopes[i] = ".".join(stack)
    return scopes


def build_call_sites(lines: List[str]) -> Dict[int, str]:
    """함수/메서드 호출 줄 -> 호출 대상 이름."""
    calls: Dict[int, str] = {}
    for i, l in enumerate(lines, start=1):
        m = re.search(r"(?P<obj>\w+(?:\.\w+)*)\s*=\s*\w+\s*\((?:\s*\w+(?:\.\w+)*\s*[=,]\s*)*\)\s*$", l)
        # 단순 호출 추적이 아니라 "호출한 함수명"만 대충 뽑는다
        m2 = re.search(r"\b(\w+)\s*\(([^#\n]*)\)\s*$", l.strip())
        if m2 and "=" not in l.split("#")[0].split("=")[0].strip().split()[0:1]:
            pass
        # 호출 부위 표시용으로는 함수명/메서드명 정도만 저장
        for cm in re.finditer(r"(?<![\.\w])(\w+)\s*\(([^#\n]*)\)\s*$", l.strip()):
            name = cm.group(1)
            if name in ("if", "for", "while", "def", "class", "return", "print", "import", "from", "with", "assert", "raise", "del", "global", "nonlocal", "yield", "lambda"):
                continue
            calls[i] = name
            break
    return calls


def extract_object_map(lines: List[str]) -> Dict[int, List[str]]:
    """각 줄에서 할당으로 만들어지는 객체명 목록."""
    objs: Dict[int, List[str]] = {}
    for i, l in enumerate(lines, start=1):
        m = PATTERNS["assign"].search(l)
        if not m:
            continue
        target = m.group("target")
        # chained assign나 튜플 unpacking은 단순화
        targets = [t.strip() for t in target.split(",")]
        objs[i] = [t for t in targets if re.match(r"^\w+(\.\w+)*$", t)]
    return objs


def find_returned_objects(lines: List[str]) -> Dict[int, List[str]]:
    """return 문에서 반환하는 객체/식 목록."""
    rets: Dict[int, List[str]] = {}
    for i, l in enumerate(lines, start=1):
        m = PATTERNS["return_stmt"].search(l.strip())
        if not m:
            continue
        val = m.group("value").strip()
        items = [v.strip() for v in val.split(",")]
        rets[i] = [x for x in items if x]
    return rets


def callers_of(lines: List[str], func_name: str) -> List[int]:
    """해당 함수/메서드를 호출하는 줄 번호."""
    out = []
    for i, l in enumerate(lines, start=1):
        if re.search(rf"\b{re.escape(func_name)}\s*\(" , l):
            out.append(i)
    return out


def is_pipeline_section(lines: List[str]) -> bool:
    return any(p.search(l) for l in lines for p in PATTERNS["pipeline"])


def resolve_object_origin(obj_name: str, lines: List[str], objs: Dict[int, List[str]], rets: Dict[int, List[str]]) -> List[Tuple[int, str]]:
    """
    obj_name이 어디서 만들어졌거나 반환됐는지 역추적.
    - 할당문(target == obj_name)
    - return 된 객체를 받은 호출 줄
    결과를 [(줄번호, 종류)] 형태로 반환.
    """
    origins: List[Tuple[int, str]] = []

    # 1) 직접 할당
    for i, targets in objs.items():
        if obj_name in targets:
            origins.append((i, "할당"))
            continue

    # 2) return 반환값 수령
    for i, vals in rets.items():
        for v in vals:
            if v == obj_name or v.endswith("." + obj_name.split(".")[-1]):
                # 반환 자체를 origin으로 보기
                origins.append((i, "return"))
                break

    # 3) 호출 결과 수령 패턴: x = foo()
    for i, l in enumerate(lines, start=1):
        m = re.match(r"\s*(?P<target>\w+(?:\.\w+)?)\s*=\s*(?P<call>\w+)", l)
        if m and m.group("target") == obj_name:
            origins.append((i, "호출결과"))

    return origins


def check(lines: List[str], is_notebook: bool = False) -> Tuple[List[str], List[str], List[str], List[str]]:
    violations = []
    suspicious = []
    clean = []
    meta = []

    scopes = build_function_scopes(lines)
    objs = extract_object_map(lines)
    rets = find_returned_objects(lines)

    fit_calls = find_lines_all(lines, PATTERNS["fit"])
    boundaries = find_boundaries(lines)
    shuffle_flags = find_lines(lines, PATTERNS["shuffle_split"])
    target_encode_flags = find_lines(lines, PATTERNS["target_encode"])
    feature_add_flags = find_lines(lines, PATTERNS["feature_add"])
    ts_hints = find_lines(lines, PATTERNS["time_series_hints"])
    transductive_flags = find_lines(lines, PATTERNS["transductive_hints"])

    if not boundaries:
        meta.append("판정 불가: train/test 또는 fold 분할 경계가 코드에서 확인되지 않음. 지적 대상이 split 경계 대비 어디에 있는지 알 수 없어 누수 여부 판정 불가.")

    if is_notebook:
        meta.append("노트북 한계: 이 검사는 셀 코드 텍스트를 저장 순서대로 이어 붙여 본다. 실제 실행 순서, 셀 재실행, 변수 덮어쓰기/재할당까지는 반영하지 못한다. 셀을 다시 실행했거나 같은 이름 객체를 재사용·재할당했으면, 여기서 잡은 줄 번호와 실제 누수 위치가 다를 수 있다. 확정 판단은 실행 환경(실제 객체·split 경계)에서 따로 확인할 것.")

    boundary_lines = [b[0] for b in boundaries]
    max_boundary = max(boundary_lines) if boundary_lines else 0

    pipeline_used = is_pipeline_section(lines)
    if pipeline_used:
        meta.append("참고: sklearn Pipeline/ColumnTransformer 사용 감지. 파이프라인 캡슐화 자체는 누수가 아님. 단 pipeline 밖에서 train/test 경계를 무시한 별도 fit/transform이 있으면 그 줄만 지적됨.")

    if ts_hints and shuffle_flags:
        for bf, bl in shuffle_flags:
            suspicious.append(f"[{bf}] 의심: 시계열/순서 데이터에서 shuffle 포함 split. 시간 순서 누수 가능. 수정: shuffle=False 또는 시간 기준 split/TimeSeriesSplit 사용.")

    if transductive_flags:
        suspicious.append("[전체] 의심: transductive/준지도자기학습 계열 사용 정황. 테스트/미관측 데이터를 학습에 쓰는 설계면 의도된 누수일 수 있음. 수정: 의도가 transductive이면 이 검사에서는 누수로 확정하지 않음. 의도가 supervised면 train만 학습에 쓰도록 분리.")

    def is_likely_fit_on_whole_before_split(fi, fl):
        return (fi <= max_boundary) and any(p.search(fl) for p in PATTERNS["imputer_scale_encode"])

    def is_fit_after_split_not_limited_to_train(fi, fl):
        if fi <= max_boundary:
            return False
        if any(k in fl for k in ["train", "X_train", "y_train", "train_df", "train["]):
            return False
        if any(k in fl for k in ["df", "data", "X", "dataset", "X_scaled"]):
            return True
        return True

    def infer_object_from_line(line):
        m = re.search(r"(\w+)\.(fit|fit_transform|transform)\s*\(", line)
        if m:
            return m.group(1)
        return ""

    def describe_origin(obj_name):
        origins = resolve_object_origin(obj_name, lines, objs, rets)
        if not origins:
            return f"({obj_name} 출처 불명확)"
        parts = []
        for oi, kind in origins:
            parts.append(f"{kind}:{oi}")
        return f"({obj_name} 기원 {', '.join(parts)})"

    # ---- fit 호출 지점 + 인자/객체 전달 추적 ----
    for fi, fl in fit_calls:
        obj_name = infer_object_from_line(fl)
        scope = scopes.get(fi, "<top>")
        origin_note = describe_origin(obj_name) if obj_name else ""

        if is_likely_fit_on_whole_before_split(fi, fl):
            viol_extra = f" {origin_note}" if origin_note else ""
            violations.append(f"[{fi}] 확정위반: split 전에 scaler/encoder/imputer.fit 을 전체 데이터로 수행 → 이후 split해도 이미 누수.{viol_extra} 수정: split 이후 train만.fit, transform은 각 fold/test에만 적용.")
            continue

        if is_fit_after_split_not_limited_to_train(fi, fl):
            if any(p.search(fl) for p in PATTERNS["imputer_scale_encode"]):
                viol_extra = f" {origin_note}" if origin_note else ""
                violations.append(f"[{fi}] 확정위반: split 이후 전체 데이터 기준으로 scaler/encoder.fit. test/val 정보가 fit에 유입됨.{viol_extra} 수정: split 이후 train만.fit, test는 transform만.")
            else:
                susp_extra = f" {origin_note}" if origin_note else ""
                suspicious.append(f"[{fi}] 의심: split 이후 fit 호출(함수/클래스 {scope}). 대상이 train 한정인지 불명확.{susp_extra} 수정: fit은 train만 기준으로, test/val은 transform/predict만.")
                # 호출 경로 추적: 이 fit 객체가 함수 반환값/호출 결과로 들어온 거면 그 호출 줄도 같이 의심 표시
                if obj_name:
                    call_sites = callers_of(lines, obj_name.split(".")[-1]) if obj_name.split(".")[-1].isidentifier() else []
                    if not call_sites:
                        # 호출 패턴으로 다시 찾기
                        for ci, cl in enumerate(lines, start=1):
                            if re.search(rf"\b{re.escape(obj_name)}\s*=", cl):
                                call_sites = [ci]
                                break
                    for ci in call_sites:
                        if ci != fi:
                            suspicious.append(f"[{ci}] 의심: 위 fit 객체({obj_name})가 이 줄에서 수령/생성(함수 반환/호출 결과)됐을 가능성. split 경계 대비 train 한정인지 확인 필요. 수정: 객체 생성·수령은 split 이후 train만 기준으로.")

    # ---- 타겟 인코딩 계열 ----
    for fi, fl in target_encode_flags:
        if re.search(r"y|target|label|class", fl, re.I):
            violations.append(f"[{fi}] 확정위반: 타겟 열 y/target/label을 피처 생성/인코딩에 직접 사용. 수정: 타겟은 평가용으로 분리 유지, 피처 생성은 X만 사용.")
        else:
            suspicious.append(f"[{fi}] 의심: 타겟 인코딩 계열 사용. split 이전에 적용됐거나 fold 바깥에서 타겟 통계 반영 가능성. 수정: fold 내부(또는 train 한정)에서만 타겟 통계 계산.")

    # ---- split 이전에 전체 df 대상 피처 추가 ----
    for fi, fl in feature_add_flags:
        if fi <= max_boundary:
            suspicious.append(f"[{fi}] 의심: split 이전에 전체 데이터 대상 피처 추가/merge/transform(함수/클래스 {scopes.get(fi, '<top>')} 이후 split해도 새 피처가 전체 정보로 계산됨. 수정: 피처 생성은 split 이후, 또는 train 한정 파이프라인으로만.")

    if any(re.search(r"^# ---|cell|셀|jupyter", l, re.I) for l in lines):
        meta.append("참고: 셀 구분 흔적(# %% 등)이 있으면 셀 실행 순서가 실제 코드 순서와 다를 수 있음. 이 검사는 텍스트 순서대로만 판단하므로 실제 실행 순서를 따로 확인할 것.")

    if is_notebook and code_cells:
        meta.append(f"참고: 노트북 파일 코드 셀 {code_cells}개와 텍스트 순서 기준으로 검사함. 셀 재실행/변수 재사용 있으면 이 결과만으로 불충분.")

    return violations, suspicious, clean, meta


def emit(violations, suspicious, clean, meta, is_notebook: bool = False):
    if violations:
        result = "결과: 확정위반"
    elif suspicious:
        result = "결과: 의심"
    elif meta and any("판정 불가" in m for m in meta):
        result = "결과: 판정 불가"
    else:
        result = "결과: 이상있음"

    print(result)
    print("-" * 40)

    if is_notebook:
        print("[노트북] 셀 저장 순서 기준 검사. 실제 실행 순서·셀 재실행·변수 재사용은 반영 안 됨.")

    for v in violations:
        print(v)
    for s in suspicious:
        print(s)
    for m in meta:
        print(m)
    if not violations and not suspicious and not meta:
        print("이상없음: 현재 패턴상 명백한 누수 없음.")


def classify_input(src: str):
    if is_empty(src):
        print("결과: 빈 입력")
        print("-" * 40)
        print("빈 입력이라 검사 불가. 검사할 파이썬 코드를 붙여넣거나 파일로 전달.")
        return False
    if not is_python_like(src):
        print("결과: 파이썬 아닌 입력")
        print("-" * 40)
        print("파이썬 코드로 보기 어려움. 파이썬 전처리/학습 코드를 붙였는지 확인 후 다시 실행.")
        return False
    return True


def main():
    ap = argparse.ArgumentParser(description="ML 전처리 코드 데이터 누수 검사 (v4)")
    ap.add_argument("files", nargs="*", help="검사할 Python/.ipynb 파일 경로")
    ap.add_argument("-c", "--code", help="코드 문자열")
    args = ap.parse_args()

    paths = []
    if args.code:
        paths = [("<코드인자>", None, True)]
    elif args.files:
        paths = [(f, None, False) for f in args.files]
    else:
        paths = [("<표준입력>", None, False)]

    if not paths:
        return

    for idx, (label, code, is_code) in enumerate(paths):
        if idx > 0:
            print()
        src = read_source(path=(label if not is_code and not label.startswith('<') else None), code=(code if is_code else None))
        if not classify_input(src):
            continue

        if isinstance(src, str) and src.startswith("노트북 읽기 실패"):
            print(f"파일: {label}")
            print("결과: 노트북 읽기 실패")
            print("-" * 40)
            print(src)
            continue

        lines = src.splitlines()
        if not is_ml_preprocessing(lines):
            print(f"파일: {label}")
            print("결과: 전처리 코드로 보기 어려움")
            print("-" * 40)
            print("ML 전처리 패턴(fit/transform/split/인코딩/스케일링 등)이 충분히 보이지 않음. 붙일 코드가 전처리/학습 파이프라인인지 확인 후 다시 실행.")
            continue

        violations, suspicious, clean, meta = check(lines, is_notebook=(label.lower().endswith(".ipynb")))
        print(f"파일: {label}")
        emit(violations, suspicious, clean, meta, is_notebook=(label.lower().endswith(".ipynb")))


if __name__ == "__main__":
    main()
